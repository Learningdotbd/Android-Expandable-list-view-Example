package com.example.mytabdemoapp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ExpandableListDataItems {
    public static HashMap<String, List<String>> getData() {
        HashMap<String, List<String>> expandableDetailList = new HashMap<String, List<String>>();

        // As we are populating List of fruits, vegetables and nuts, using them here
        // We can modify them as per our choice.
        // And also choice of fruits/vegetables/nuts can be changed
        List<String> Football = new ArrayList<String>();
        Football.add("Belgium");
        Football.add("Brazil");
        Football.add("France");
        Football.add("England");
        Football.add("Argentina");


        List<String> Cricket = new ArrayList<String>();
        Cricket.add("New Zealand");
        Cricket.add("England");
        Cricket.add("India");
        Cricket.add("South Africa");
        Cricket.add("Pakistan");
        Cricket.add("Bangladesh");



        List<String> Basketball = new ArrayList<String>();
        Basketball.add("USA");
        Basketball.add("Spain");
        Basketball.add("Australia");
        Basketball.add("Slovenia");
        Basketball.add("France");

         List<String> Badminton = new ArrayList<String>();
         Badminton.add("Denmark");
         Badminton.add("Japan");
         Badminton.add("Indonesia");
         Badminton.add("China");




        // Fruits are grouped under Fruits Items. Similarly the rest two are under
        // Vegetable Items and Nuts Items respectively.
        // i.e. expandableDetailList object is used to map the group header strings to
        // their respective children using an ArrayList of Strings.
        expandableDetailList.put("Football Teams", Football);
        expandableDetailList.put("Cricket Teams", Cricket);
        expandableDetailList.put("Basketball Teams", Basketball);
        expandableDetailList.put("Badminton Teams", Badminton);

        return expandableDetailList;
    }
}
